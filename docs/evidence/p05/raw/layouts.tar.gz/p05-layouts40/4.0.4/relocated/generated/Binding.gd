extends Node
const Element = preload("res://modules/UI toolkit/runtime/composition/element.gd")
const Toggle = preload("res://modules/UI toolkit/runtime/node/toggle.gd")
signal enabled_changed(previous: bool, value: bool)
var enabled: bool = false:
    set(_gogo_incoming_enabled):
        if is_same(enabled, _gogo_incoming_enabled): return
        var _gogo_previous_enabled: bool = enabled
        enabled = _gogo_incoming_enabled
        enabled_changed.emit(_gogo_previous_enabled, _gogo_incoming_enabled)
    get:
        preload("../../../modules/UI toolkit/runtime/composition/state.tres").observe(self, &"enabled_changed")
        return enabled

func build_view() -> Element:
    return _GogoFactories_0._gogo_build_0((preload("../../../modules/UI toolkit/runtime/composition/binding.gd").new(self, func(_gogo_root): return _gogo_root if _gogo_root != null else null, "enabled", func(_gogo_source, _gogo_edit: bool): _gogo_source.enabled = _gogo_edit, "enabled")))


func _notification(_gogo_what: int) -> void:
    preload("../../../modules/UI toolkit/runtime/composition/state.tres").lifecycle(self, _gogo_what)


class _GogoFactories_0:
    const _GogoElement_0 = preload("../../../modules/UI toolkit/runtime/composition/element.gd")


    static func _gogo_build_0(_gogo_value_0: Variant) -> _GogoElement_0:
        var _gogo_element_0 := _GogoElement_0.new(Toggle, {"name": "Toggle", "text": "Direct binding"}, {}, [], "examples/counter/Binding.gogo:6:12", null, false)
        _gogo_element_0.bindings = {"value": _gogo_value_0}
        return _gogo_element_0
