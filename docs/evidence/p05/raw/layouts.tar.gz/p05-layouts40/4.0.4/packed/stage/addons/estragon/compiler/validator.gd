@tool
extends RefCounted
## Static native Node property/signal contracts; no SceneTree or editor dependency.
const Element = preload("../runtime/composition/element.gd")
const Model = preload("model.gd")
const Source = preload("source.gd")
const Resolver = preload("native/resolver.gd")
const Length = preload("../runtime/node/internal/length.gd")
const Lexer = preload("lexer.gd")
var file: Source
var resolver
var current_module
func _init(source: Source) -> void:
	file = source
	resolver = Resolver.new(source)
func validate(module: Model.Module) -> void:
	current_module = module
	resolver.scan(module)
	for part in module.parts: _node(part)
func _node(node: Model.SyntaxNode) -> void:
	if not file.diagnostics.is_empty(): return
	if node is Model.GdExpression:
		for part in node.parts: _node(part)
	elif node is Model.Component: _component(node)
func _error(message: String, span: Model.Span) -> void:
	file.fail(message,span.start.index,span.end.index)

func _component(node: Model.Component) -> void:
	var resolved: Dictionary = resolver.resolve(node.name, node.name_span)
	if resolved.is_empty(): return
	node.runtime_class = resolved.get("project_alias",resolved.get("native_alias",node.name))
	var properties: Dictionary = {}
	var signals: Dictionary = {}
	for property in ClassDB.class_get_property_list(resolved.native): properties[property.name] = property
	for event in ClassDB.class_get_signal_list(resolved.native): signals[event.name] = event
	var script: Script = resolved.script
	while script != null:
		for property in script.get_script_property_list():
			if not properties.has(property.name): properties[property.name] = property
		for event in script.get_script_signal_list():
			if not signals.has(event.name): signals[event.name] = resolver.signal_contract(script,event)
		script = script.get_base_script()
	properties.merge(resolved.get("properties",{}),true)
	signals.merge(resolved.get("signals",{}),true)
	var seen: Dictionary = {}
	for attribute in node.attributes:
		var name := attribute.name
		if seen.has(name):
			_error("Duplicate Node property or signal " + name, attribute.name_span)
			return
		seen[name] = true
		if name.begins_with("bind:"):
			_binding(attribute,node,properties,signals)
			if not file.diagnostics.is_empty(): return
			continue
		if name=="key":
			attribute.kind = "key"
			attribute.type_name = "Variant"
			if attribute.value is Model.Literal:
				if str(attribute.value.value).is_empty(): _error("GGX key must be an integer or nonempty String",attribute.value.span)
			else: _key_expression(attribute.value)
			continue
		if signals.has(name):
			attribute.kind = "signal"
			attribute.type_name = "Callable"
			if not attribute.value is Model.GdExpression:
				_error("Node signals require a named handler/Callable expression", attribute.value.span)
				return
			var lexer := Lexer.new(file)
			var index: int = attribute.value.span.start.index + 1
			while index < attribute.value.span.end.index - 1:
				var token := lexer.next_token(index)
				if token == null: return
				if token.kind == "identifier" and token.text == "func":
					_error("Inline anonymous GGX handlers are not supported; use a named handler/Callable", token.span)
					return
				index = token.span.end.index
		elif properties.has(name) and name not in ["owner", "script"] and not name.contains("/") and not (int(properties[name].usage) & PROPERTY_USAGE_READ_ONLY):
			attribute.type_name = "Variant" if Length.registered(resolved.script,name) else _native_type(properties[name])
			if attribute.type_name.is_empty():
				_error("Unsupported Node property metadata: " + name, attribute.name_span)
				return
		else:
			_error("Removed layout API "+name+": use unit dimensions, flex and stretch" if name in ["fill_width","fill_height","viewport_width_scale","viewport_height_scale"] else "Unknown, read-only or reserved Node property/signal " + name, attribute.name_span)
			return
		var is_length := Length.registered(resolved.script,name)
		if is_length:
			_length(attribute,Length.domain(name))
			if not file.diagnostics.is_empty(): return
		if attribute.value is Model.Literal:
			if is_length:
				attribute.value.kind = "string-literal"
				continue
			if attribute.type_name not in ["String", "StringName"]:
				_error("Typed Node values require {GDScript expressions}; only strings may be quoted", attribute.value.span)
				return
			attribute.value.kind = "string-literal"
			attribute.value.type_name = attribute.type_name
		else:
			_node(attribute.value)
	var sibling_names := {}
	for child in node.children:
		if child is Model.GdExpression:
			_node(child)
			_child_expression(child)
			continue
		if not child is Model.Component:
			_error("Node GGX children must be newly declared Node elements; expression adoption is unsupported", child.span)
			return
		_node(child)
		if child is Model.Component:
			for attribute in child.attributes:
				if attribute.name=="name" and attribute.value is Model.Literal:
					var name: String = str(attribute.value.value)
					if sibling_names.has(name):
						_error("Duplicate declared sibling name "+name,attribute.value.span)
						return
					sibling_names[name] = true
	_static_keys(node.children,{})

# Inspect only statically simultaneous children. A conditional expression's
# alternatives are validated at runtime; it must not create false duplicates.
func _static_keys(children: Array, keys: Dictionary) -> void:
	for child in children:
		if child is Model.Component:
			for attribute in child.attributes:
				if attribute.kind!="key": continue
				var literal = null
				if attribute.value is Model.Literal: literal = "s:"+str(attribute.value.value)
				else:
					var text: String = file.slice(attribute.value.span).substr(1).trim_suffix("}").strip_edges()
					if text.is_valid_int(): literal = "i:"+str(int(text))
					else:
						var tokens := _expression_tokens(attribute.value)
						if tokens.size()==1 and tokens[0].kind=="string" and not tokens[0].text.contains("\\"):
							var value: String = tokens[0].text
							var delimiter := 3 if value.begins_with(value[0].repeat(3)) else 1
							literal = "s:"+value.substr(delimiter,value.length()-delimiter*2)
				if literal==null: continue
				if keys.has(literal):
					_error("Duplicate declared sibling key "+str(literal),attribute.value.span)
					return
				keys[literal] = true
		elif child is Model.GdExpression:
			var conditional := false
			var lexer := Lexer.new(file)
			for part in child.parts:
				if not part is Model.Code: continue
				var cursor: int = part.span.start.index
				while cursor<part.span.end.index:
					var token = lexer.next_token(cursor)
					if token==null: return
					cursor = token.span.end.index
					if token.kind=="identifier" and token.text=="if": conditional = true
			if not conditional: _static_keys(child.parts,keys)

func _key_expression(expression) -> void:
	var tokens := _expression_tokens(expression)
	if tokens.is_empty(): return
	# Token kinds keep strings/comments containing constructor-looking text
	# ordinary values; never classify source by substring replacement.
	var first: String = tokens[0].text
	var invalid := false
	if tokens.size()==1:
		invalid = first in ["<element>","null","true","false",'""',"''",'""""""',"''''''"] or tokens[0].kind=="number" and first.is_valid_float() and not first.is_valid_int()
	elif tokens.size()==2 and first in ["+","-"] and tokens[1].kind=="number":
		invalid = tokens[1].text.is_valid_float() and not tokens[1].text.is_valid_int()
	elif first in ["[","{","&","<element>"]: invalid = true
	elif tokens.size()>1 and tokens[1].text=="(" and _direct_call(tokens,1):
		invalid = first in ["bool","float","StringName","Vector2","Vector3","Color","Dictionary","NodePath"]
	elif tokens.size()>3 and tokens[1].text=="." and tokens[2].text=="new" and tokens[3].text=="(" and _direct_call(tokens,3): invalid = true
	if invalid: _error("GGX key must be an integer or nonempty String",expression.span)
func _direct_call(tokens: Array, start: int) -> bool:
	var depth := 0
	for index in range(start,tokens.size()):
		if tokens[index].text=="(": depth += 1
		elif tokens[index].text==")":
			depth -= 1
			if depth==0: return index==tokens.size()-1
	return false
func _expression_tokens(expression) -> Array:
	var tokens: Array = []
	var lexer := Lexer.new(file)
	for part in expression.parts:
		if part is Model.Component:
			tokens.append({"text":"<element>","kind":"element","span":part.span})
			continue
		var cursor: int = part.span.start.index
		while cursor < part.span.end.index:
			var token = lexer.next_token(cursor)
			if token==null: return []
			cursor = token.span.end.index
			if token.kind not in ["whitespace","comment","newline","continuation"]: tokens.append({"text":token.text,"kind":token.kind,"span":token.span})
	return tokens
func _child_expression(expression) -> void:
	_child_result(_expression_tokens(expression),expression.span)
func _child_result(tokens: Array, span) -> void:
	# Result alternatives are descriptions/null/sequences; the condition remains
	# normal native GDScript. This closes the Variant ternary loophole where
	# Godot defers an int/Object conversion until gameplay.
	if tokens.size()==1 and tokens[0].text in ["<element>","null"]: return
	var depth := 0
	var conditional := -1
	var alternative := -1
	var outer_close := -1
	for index in range(tokens.size()):
		var value: String = tokens[index].text
		if value in ["(","[","{"]: depth += 1
		elif value in [")","]","}"]:
			depth -= 1
			if depth==0 and outer_close<0: outer_close = index
		elif depth==0:
			if value=="if" and conditional<0: conditional = index
			elif value=="else" and conditional>=0:
				alternative = index
				break
	if not tokens.is_empty() and tokens[0].text=="(" and outer_close==tokens.size()-1:
		_child_result(tokens.slice(1,tokens.size()-1),span)
		return
	if conditional>0 and alternative>conditional+1 and alternative<tokens.size()-1:
		_child_result(tokens.slice(0,conditional),span)
		_child_result(tokens.slice(alternative+1),span)
		return
	if tokens.size()>=2 and tokens[0].text=="[" and outer_close==tokens.size()-1:
		var begin := 1
		depth = 0
		for index in range(1,tokens.size()-1):
			var value: String = tokens[index].text
			if value in ["(","[","{"]: depth += 1
			elif value in [")","]","}"]: depth -= 1
			elif value=="," and depth==0:
				_child_result(tokens.slice(begin,index),span)
				begin = index+1
		if begin<tokens.size()-1: _child_result(tokens.slice(begin,tokens.size()-1),span)
		return
	# Unknown native expressions (locals, typed helper returns, Array.map) are
	# runtime-validated as a complete desired tree. Obvious scalar/newly-created Node
	# leaves fail at their authored span, including conditional alternatives.
	if not tokens.is_empty():
		var first: String = tokens[0].text
		var constructor: bool = tokens.size()>3 and tokens[1].text=="." and tokens[2].text=="new" and tokens[3].text=="(" and _direct_call(tokens,3)
		var scalar_call: bool = tokens.size()>1 and tokens[1].text=="(" and _direct_call(tokens,1) and first in ["int","float","bool","String","StringName","Vector2","Vector3","Color","Dictionary","NodePath"]
		if tokens[0].kind=="identifier" and first not in ["true","false"] and not scalar_call and (not constructor or resolver.aliases.get(first,"")==(Element as Script).resource_path):
			return
	_error("GGX children require Element, null, nested Arrays or borrowed scene children; scalars/newly constructed Nodes reject",tokens[0].span if not tokens.is_empty() else span)

func _native_type(property: Dictionary) -> String:
	if property.type == TYPE_OBJECT:
		var native: String = str(property.get("class_name", ""))
		return native if not native.is_empty() else "Object"
	if property.type == TYPE_NIL: return "Variant"
	# Names are stable Variant types, not an engine-version-specific type_string API.
	return {TYPE_BOOL:"bool", TYPE_INT:"int", TYPE_FLOAT:"float", TYPE_STRING:"String", TYPE_STRING_NAME:"StringName", TYPE_VECTOR2:"Vector2", TYPE_VECTOR2I:"Vector2i", TYPE_RECT2:"Rect2", TYPE_RECT2I:"Rect2i", TYPE_VECTOR3:"Vector3", TYPE_VECTOR3I:"Vector3i", TYPE_TRANSFORM2D:"Transform2D", TYPE_VECTOR4:"Vector4", TYPE_VECTOR4I:"Vector4i", TYPE_PLANE:"Plane", TYPE_QUATERNION:"Quaternion", TYPE_AABB:"AABB", TYPE_BASIS:"Basis", TYPE_TRANSFORM3D:"Transform3D", TYPE_PROJECTION:"Projection", TYPE_COLOR:"Color", TYPE_NODE_PATH:"NodePath", TYPE_RID:"RID", TYPE_CALLABLE:"Callable", TYPE_SIGNAL:"Signal", TYPE_DICTIONARY:"Dictionary", TYPE_ARRAY:"Array", TYPE_PACKED_BYTE_ARRAY:"PackedByteArray", TYPE_PACKED_INT32_ARRAY:"PackedInt32Array", TYPE_PACKED_INT64_ARRAY:"PackedInt64Array", TYPE_PACKED_FLOAT32_ARRAY:"PackedFloat32Array", TYPE_PACKED_FLOAT64_ARRAY:"PackedFloat64Array", TYPE_PACKED_STRING_ARRAY:"PackedStringArray", TYPE_PACKED_VECTOR2_ARRAY:"PackedVector2Array", TYPE_PACKED_VECTOR3_ARRAY:"PackedVector3Array", TYPE_PACKED_COLOR_ARRAY:"PackedColorArray"}.get(property.type, "")

func _binding(attribute, node, properties: Dictionary, signals: Dictionary) -> void:
	if attribute.name!="bind:value":
		_error("Only bind:value is supported",attribute.name_span)
		return
	for peer in node.attributes:
		if peer.name in ["value","value_changed"]:
			_error("bind:value conflicts with value/value_changed",peer.name_span)
			return
	var event: Dictionary = signals.get("value_changed",{})
	var args: Array = event.get("args",[])
	if not properties.has("value") or properties.value.type!=TYPE_BOOL or int(properties.value.usage)&PROPERTY_USAGE_READ_ONLY or args.size()!=1 or args[0].type!=TYPE_BOOL:
		_error("bind:value requires writable bool value and value_changed(value: bool)",attribute.name_span)
		return
	if not attribute.value is Model.GdExpression:
		_error("bind:value requires an explicit self bindable lvalue path",attribute.value.span)
		return
	var tokens := _expression_tokens(attribute.value)
	if tokens.size()<3 or tokens.size()%2!=1 or tokens[0].text!="self":
		_error("bind:value requires self.field or self.model.field",attribute.value.span)
		return
	var names: Array = []
	for index in range(1,tokens.size()):
		if index%2==1 and tokens[index].text!="." or index%2==0 and tokens[index].kind!="identifier":
			_error("bind:value accepts only assignable identifier paths",tokens[index].span)
			return
		if index%2==0: names.append(tokens[index].text)
	if not resolver.bindable_path(current_module,names):
		_error("bind:value path requires typed Gogo bindable fields ending in bool",attribute.value.span)
		return
	attribute.kind = "binding"
	attribute.type_name = "Variant"
	attribute.binding_path = names

func _length(attribute, domain: String) -> void:
	var value = attribute.value
	if value is Model.Literal:
		var parsed := Length.parse(value.value,domain)
		if parsed.has("error"): _error(parsed.error,value.span)
		return
	var tokens := _expression_tokens(value)
	var text := ""
	if tokens.size()==1: text = tokens[0].text
	elif tokens.size()==2 and tokens[0].text in ["+","-"] and tokens[1].kind=="number": text = tokens[0].text+tokens[1].text
	if tokens.size()==1 and tokens[0].kind=="string":
		var parsed := Length.parse(text.substr(1,text.length()-2).c_unescape(),domain)
		if parsed.has("error"): _error(parsed.error,value.span)
	elif text in ["true","false","null"]:
		_error("Length requires int, float or a unit string",value.span)
	elif text in ["NAN","INF","-INF","+INF"]:
		_error("Length must be finite",value.span)
	elif text.is_valid_float():
		var parsed := Length.parse(float(text),domain)
		if parsed.has("error"): _error(parsed.error,value.span)
