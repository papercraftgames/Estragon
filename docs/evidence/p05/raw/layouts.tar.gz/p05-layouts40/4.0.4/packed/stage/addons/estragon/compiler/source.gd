@tool
extends RefCounted
## Source ranges use code-point indexes internally and compatible UTF-16 externally.
const Model = preload("model.gd")
var text: String
var name: String
var output_path: String
var project
var diagnostics: Array[Model.Diagnostic] = []
var _lines: PackedInt32Array = [0]
var _utf16: PackedInt32Array = [0]

func _init(value: String, source_name: String = "<source>", generated_path: String = "", project_sources = null) -> void:
	text = value
	name = source_name
	output_path = generated_path
	project = project_sources
	for index in range(text.length()):
		_utf16.append(_utf16[-1] + (2 if text.unicode_at(index) > 0xffff else 1))
		if text[index] == "\n" or text[index] == "\r" and (index + 1 == text.length() or text[index + 1] != "\n"):
			_lines.append(index + 1)

func generated_path() -> String:
	if not output_path.is_empty(): return output_path
	if not "/" in name: return "res://Generated.gd"
	return name.get_base_dir().path_join("generated").path_join(name.get_file().get_basename() + ".gd")

func position(index: int) -> Model.Position:
	index = clampi(index, 0, text.length())
	var low: int = 0
	var high := _lines.size()
	while low + 1 < high:
		var middle := (low + high) >> 1
		if _lines[middle] <= index: low = middle
		else: high = middle
	var point := Model.Position.new()
	point.index = index
	point.offset = _utf16[index]
	point.line = low + 1
	point.column = _utf16[index] - _utf16[_lines[low]] + 1
	return point

func line_start(line: int) -> int:
	return _lines[line - 1] if line > 0 and line <= _lines.size() else text.length()

func span(start: int, end: int = -1) -> Model.Span:
	var result := Model.Span.new()
	result.start = position(start)
	result.end = position(start if end < 0 else end)
	return result

func fail(message: String, start: int, end: int = -1) -> void:
	if not diagnostics.is_empty(): return
	var diagnostic := Model.Diagnostic.new()
	diagnostic.source_name = name
	diagnostic.span = span(start, end)
	diagnostic.message = message
	diagnostics.append(diagnostic)

func slice(bounds: Model.Span) -> String:
	return text.substr(bounds.start.index, bounds.end.index - bounds.start.index)

## Convert compatible UTF-16 offsets/coordinates to Godot slicing indexes.
func index_at_offset(offset_value: int) -> int:
	var low: int = 0
	var high := _utf16.size()
	while low + 1 < high:
		var middle := (low + high) >> 1
		if _utf16[middle] <= offset_value: low = middle
		else: high = middle
	return low

func offset(line: int, column: int = 1) -> int:
	return mini(_utf16[-1], _utf16[line_start(line)] + maxi(0, column - 1))

## Relative resource references shared by emission and editor starter templates.
static func relative_path(directory: String, resource_path: String) -> String:
	var origin := ProjectSettings.globalize_path(directory).simplify_path().split("/", false)
	var target := ProjectSettings.globalize_path(resource_path).simplify_path().split("/", false)
	var shared := 0
	while shared < mini(origin.size(), target.size()) and origin[shared] == target[shared]: shared += 1
	return "../".repeat(origin.size() - shared) + "/".join(target.slice(shared))
